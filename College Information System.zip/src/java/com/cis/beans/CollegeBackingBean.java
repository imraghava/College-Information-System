/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.beans;

import com.cis.dao.*;
import com.cis.models.*;
import java.util.ArrayList;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpSession;

/**
 *
 * @author home
 */
public class CollegeBackingBean {
    
    private String collegeCode;
    private College newCollege = new College();
    private Department newDept = new Department();
    private Event newEvent = new Event();
    private Faculty newFaculty = new Faculty();
    private Infrastructure newInfra = new Infrastructure();
    private Library newLibrary = new Library();
    private Placements clgPlacements = new Placements();
    private RankRange rankRange = new RankRange();
    private College searchClg = new College();
    private List<College> clgSearchResults = new ArrayList();
    private College selectedObj = new College();
    private Placements newPlacement = new Placements();
    private List<Placements> placementsList = new ArrayList();
    private boolean boolClgAdded = false;
    private boolean boolDeptAdded = false;
    private boolean boolEventAdded = false;
    private boolean boolPlacementAdded = false;
    private boolean boolRankAdded = false;
    private Comments newReviewComments = new Comments();
    private List<Comments> reviewCommentsList = new ArrayList();

    public Comments getNewReviewComments() {
        return newReviewComments;
    }

    public void setNewReviewComments(Comments newReviewComments) {
        this.newReviewComments = newReviewComments;
    }

    public List<Comments> getReviewCommentsList() {
        return reviewCommentsList;
    }

    public void setReviewCommentsList(List<Comments> reviewCommentsList) {
        this.reviewCommentsList = reviewCommentsList;
    }
    
    

    public boolean isBoolDeptAdded() {
        return boolDeptAdded;
    }

    public void setBoolDeptAdded(boolean boolDeptAdded) {
        this.boolDeptAdded = boolDeptAdded;
    }

    public boolean isBoolEventAdded() {
        return boolEventAdded;
    }

    public void setBoolEventAdded(boolean boolEventAdded) {
        this.boolEventAdded = boolEventAdded;
    }

    public boolean isBoolPlacementAdded() {
        return boolPlacementAdded;
    }

    public void setBoolPlacementAdded(boolean boolPlacementAdded) {
        this.boolPlacementAdded = boolPlacementAdded;
    }

    public boolean isBoolRankAdded() {
        return boolRankAdded;
    }

    public void setBoolRankAdded(boolean boolRankAdded) {
        this.boolRankAdded = boolRankAdded;
    }
    
    
    

    public boolean isBoolClgAdded() {
        return boolClgAdded;
    }

    public void setBoolClgAdded(boolean boolClgAdded) {
        this.boolClgAdded = boolClgAdded;
    }
    
    
    
    private List<Event> eventsList = new ArrayList();

    public List<Event> getEventsList() {
        return eventsList;
    }

    public void setEventsList(List<Event> eventsList) {
        this.eventsList = eventsList;
    }
    
    

    public List<Placements> getPlacementsList() {
        return placementsList;
    }

    public void setPlacementsList(List<Placements> placementsList) {
        this.placementsList = placementsList;
    }
    

    public Placements getNewPlacement() {
        return newPlacement;
    }

    public void setNewPlacement(Placements newPlacement) {
        this.newPlacement = newPlacement;
    }
    
    private RankRange newRankRange = new RankRange();

    public RankRange getNewRankRange() {
        return newRankRange;
    }

    public void setNewRankRange(RankRange newRankRange) {
        this.newRankRange = newRankRange;
    }
    
    
    
    public College getSelectedObj() {
        return selectedObj;
    }

    public void setSelectedObj(College selectedObj) {
        this.selectedObj = selectedObj;
    }
    

    public List<College> getClgSearchResults() {
        return clgSearchResults;
    }

    public void setClgSearchResults(List<College> clgSearchResults) {
        this.clgSearchResults = clgSearchResults;
    }
    

    public College getSearchClg() {
        return searchClg;
    }

    public void setSearchClg(College searchClg) {
        this.searchClg = searchClg;
    }
    
    

    public String getCollegeCode() {
        return collegeCode;
    }

    public void setCollegeCode(String collegeCode) {
        this.collegeCode = collegeCode;
    }
    
    
    private List<Department> newDepartList = new ArrayList();
    private List<RankRange> ranksList = new ArrayList();

    public List<RankRange> getRanksList() {
        return ranksList;
    }

    public void setRanksList(List<RankRange> ranksList) {
        this.ranksList = ranksList;
    }
    
    

    public List<Department> getNewDepartList() {
        return newDepartList;
    }

    public void setNewDepartList(List<Department> newDepartList) {
        this.newDepartList = newDepartList;
    }
    
    
    

    public Placements getClgPlacements() {
        return clgPlacements;
    }

    public void setClgPlacements(Placements clgPlacements) {
        this.clgPlacements = clgPlacements;
    }

    public Department getNewDept() {
        return newDept;
    }

    public void setNewDept(Department newDept) {
        this.newDept = newDept;
    }

    public Event getNewEvent() {
        return newEvent;
    }

    public void setNewEvent(Event newEvent) {
        this.newEvent = newEvent;
    }

    public Faculty getNewFaculty() {
        return newFaculty;
    }

    public void setNewFaculty(Faculty newFaculty) {
        this.newFaculty = newFaculty;
    }

    public Infrastructure getNewInfra() {
        return newInfra;
    }

    public void setNewInfra(Infrastructure newInfra) {
        this.newInfra = newInfra;
    }

    public Library getNewLibrary() {
        return newLibrary;
    }

    public void setNewLibrary(Library newLibrary) {
        this.newLibrary = newLibrary;
    }

    public RankRange getRankRange() {
        return rankRange;
    }

    public void setRankRange(RankRange rankRange) {
        this.rankRange = rankRange;
    }
    
            

    public College getNewCollege() {
        return newCollege;
    }

    public void setNewCollege(College newCollege) {
        this.newCollege = newCollege;
    }
    
    
    
    
    public String navigateToAddClgInfo(){
        newCollege = new College();
        this.boolClgAdded = false;
        return "addclginformation";
    }
    
    public String navigateToAdvSearch(){
        searchClg = new College();
        return "advancedsearch";
    }
    
    public String addCollegeInformation(){
        CollegeDao dao = new CollegeDao();
        this.collegeCode = newCollege.getCollegeCode();
        dao.addCollegeInfo(newCollege);
        if(newCollege.getErrorMessage() != null && newCollege.getErrorMessage().equals("success")){
            this.addInfo("College Info got added successfully !!!");
            this.boolClgAdded = true;
        }else{
            this.boolClgAdded = false;
            this.addError(newCollege.getErrorMessage());
        }
        //return "adddepartment";
        return "";
    }
    
    public String goToDepartment(){
        this.boolDeptAdded = false;
        newDept = new Department();
        return "adddepartment";
    }
    
    public String tempAddDepart(){
        Department obj = new Department();
        obj.setCollegeCode(this.collegeCode);
        if(null == newDept.getDepartName() || "".equals(newDept.getDepartName())){
            this.addError("Please provide department name");
            return "";
        }
        obj.setDepartName(newDept.getDepartName());
        obj.setNoOfSeats(newDept.getNoOfSeats());
        this.newDepartList.add(obj);
        newDept = new Department();
        return "";
    }
    
    public String tempAddRanks(){
        RankRange obj = new RankRange();
        obj.setCollegeCode(newRankRange.getCollegeCode());
        obj.setDeptName(newRankRange.getDeptName());
        obj.setCategory(newRankRange.getCategory());
        obj.setMinRank(newRankRange.getMinRank());
        obj.setMaxRank(newRankRange.getMaxRank());
        ranksList.add(obj);
        return "";
    }
    
    public String tempAddPlacements(){
        Placements obj = new Placements();
        obj.setCollegeCode(newPlacement.getCollegeCode());
        obj.setCompany(newPlacement.getCompany());
        obj.setDepartmentName(newPlacement.getDepartmentName());
        obj.setTotalStudents(newPlacement.getTotalStudents());
        placementsList.add(obj);
        return "";
    }
    
     public String tempAddEvents(){
        Event obj = new Event();
        obj.setCollegeCode(newEvent.getCollegeCode());
        obj.setDeptName(newEvent.getDeptName());
        obj.setEventsHeld(newEvent.getEventsHeld());
        obj.setDescription(newEvent.getDescription());
        eventsList.add(obj);
        return "";
    }

    public String addEventsInfo(){
        EventsDao dao = new EventsDao();
        String mesg =dao.addEventsInfo(eventsList);
        if(mesg != null && "success".equals(mesg)){
            this.boolEventAdded=true;
            this.addInfo("Department got added successfully !!");
        }else{
            this.boolEventAdded=false;
            this.addError(mesg);
        }
        return "";
    }
     
    
    public String addPlacementsInfo(){
        PlacementsDao dao = new PlacementsDao();
        String mesg = dao.addPlacementsInfo(placementsList);
        if(mesg != null && "success".equals(mesg)){
            this.boolPlacementAdded=true;
            this.addInfo("Department got added successfully !!");
        }else{
            this.boolPlacementAdded=false;
            this.addError(mesg);
        }
        return "";
    }
    
    public String goToEvents(){
        this.boolEventAdded = false;
        newEvent = new Event();
        newEvent.setCollegeCode(collegeCode);
        return "addevents";
    }
    
    public String addRanksInfo(){
        RankDao dao = new RankDao();
        String mesg = dao.addRankInfo(collegeCode, ranksList);
        if(mesg != null && "success".equals(mesg)){
            this.boolRankAdded=true;
            this.addInfo("Rank Details got added successfully !!");
        }else{
            this.boolRankAdded=false;
            this.addError(mesg);
        }
        return "";
    }
    
    public String goToPlacements(){
        this.boolPlacementAdded=false;
        newPlacement = new Placements();
        newPlacement.setCollegeCode(collegeCode);
        return "addplacements";
    }
    public String addDepartments(){
        DepartmentDao dao = new DepartmentDao();
        String mesg = dao.addDepartmentInfo(collegeCode, newDepartList);
        if(mesg != null && "success".equals(mesg)){
            this.boolDeptAdded=true;
            this.addInfo("Department got added successfully !!");
        }else{
            this.boolDeptAdded=false;
            this.addError(mesg);
        }
        return "";
    }
    
    public String goToRankInfo(){
        this.boolRankAdded = false;
        newRankRange = new RankRange();
        newRankRange.setCollegeCode(this.collegeCode);
        return "gotoranks";
    }
    
    public String searchClgInfo(){
        CollegeDao dao = new CollegeDao();
        clgSearchResults =  dao.searchCollegeInfo(searchClg);
        return "clgSearchResult";
    }
    
    
    public String searchClgInfoBasedonRank(){
        CollegeDao dao = new CollegeDao();
        clgSearchResults =  dao.searchCollegeInfoBasedOnRank(searchClg);
        return "clgSearchResult";
    }
    
    public String prepareSearchClg(){
        searchClg = new College();
        return "searchColgInfo";
    }
    
    
    public String viewClgInfo(){
        CollegeDao dao = new CollegeDao();
        dao.viewCollegeDetails(selectedObj);
        return "viewclginformation";
    }
    
    public String reviewClgInfo(){
        CollegeDao dao = new CollegeDao();
        newReviewComments = new Comments();
        newReviewComments.setUserName(getUserInSession());
        newReviewComments.setCollegeCode(this.selectedObj.getCollegeCode());
        reviewCommentsList = dao.getReviewComments(newReviewComments);
        return "reviewclginfo";
    }
    
    
    
    public String addReviewClgInfo(){
        CollegeDao dao = new CollegeDao();
        dao.addReviewComments(newReviewComments);
        reviewCommentsList = dao.getReviewComments(newReviewComments);
        return "reviewclginfo";
    }
    
      public void addInfo(String message) {  
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,message," "));  
    }  
  
    public void addWarn(String message) {  
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,message, " "));  
    }  
  
    public void addError(String message) {  
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,message, " "));  
    }  
  
    public void addFatal(ActionEvent actionEvent) {  
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL,"Sample fatal message", "Fatal Error in System"));  
    }  
    
    
     public String getUserInSession() {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(true);
        String username = (String)session.getAttribute("username");
        return username;
    }
     
     
    public String activiatePlacements(){
        PlacementsDao dao = new PlacementsDao();
        dao.activatePlacements(this.selectedObj.getCollegeCode());
        return viewClgInfo();
    } 
}
