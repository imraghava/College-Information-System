/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.beans;

import com.cis.dao.LoginDao;
import com.cis.models.User;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpSession;

/**
 *
 * @author home
 */
public class LoginBackingBean {
    
    private String userName;
    private String password;
    private boolean boolLoginSuccess = false;
    private boolean boolAdminUser = false;
    private boolean boolClgAdmin = false;
    private boolean registeredSuccssfully = false;

    public boolean isRegisteredSuccssfully() {
        return registeredSuccssfully;
    }

    public void setRegisteredSuccssfully(boolean registeredSuccssfully) {
        this.registeredSuccssfully = registeredSuccssfully;
    }
    
    

    public boolean isBoolAdminUser() {
        return boolAdminUser;
    }

    public void setBoolAdminUser(boolean boolAdminUser) {
        this.boolAdminUser = boolAdminUser;
    }

    public boolean isBoolClgAdmin() {
        return boolClgAdmin;
    }

    public void setBoolClgAdmin(boolean boolClgAdmin) {
        this.boolClgAdmin = boolClgAdmin;
    }
    
    
    
    private User newUser ;

    public User getNewUser() {
        return newUser;
    }

    public void setNewUser(User newUser) {
        this.newUser = newUser;
    }
    

    public boolean isBoolLoginSuccess() {
        return boolLoginSuccess;
    }

    public void setBoolLoginSuccess(boolean boolLoginSuccess) {
        this.boolLoginSuccess = boolLoginSuccess;
    }
    

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String logoutAction(){
        this.userName="";
        this.password="";
        this.boolLoginSuccess=false;
        FacesContext fc = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession)fc.getExternalContext().getSession(true);
        session.invalidate();
        return "login";
    }
    
    public String addNewUser(){
        LoginDao dao = new LoginDao();
        if(newUser.getTypeOfUser() == null || "".equals(newUser.getTypeOfUser())){
            newUser.setTypeOfUser("ANONYMUS");
        }
        if(!newUser.getPassword().equals(newUser.getConfirmPassword())){
            this.addError("Passoword and confirm password are not matching");
            return "";
        }
        String mesg = dao.addNewUser(newUser);
        if(mesg == "success"){
            registeredSuccssfully = true;
            this.addInfo("User registered successfully");
        }else{
            registeredSuccssfully = false;
            this.addError(mesg);
        }
        return "";
    }
    
    public String loginAction(){
        User userObj = new User();
        userObj.setUserName(this.getUserName());
        userObj.setPassword(this.getPassword());
        
        System.out.println(" user entered is "+this.getUserName());
        System.out.println(" password entered is "+this.getPassword());
        
        LoginDao dao = new LoginDao();
        String output = dao.validateUser(userObj);
        
        System.out.println(" the result is --> "+output);
        if(userObj.getTypeOfUser() != null){
             this.boolLoginSuccess = true;
             if("ADMIN".equals(userObj.getTypeOfUser())){
                 this.boolAdminUser=true;
             }else if("CLGADMIN".equals(userObj.getTypeOfUser())){
                 this.boolClgAdmin=true;
                 this.boolAdminUser=false;
             }
             this.setUserRoleInSession(userObj.getTypeOfUser());
             this.setUserInSession(userName);
             return "success";
        }else{
            this.boolAdminUser=false;
            this.boolClgAdmin=false;
            this.addError("Please provide valid login credentials.");
            this.boolLoginSuccess=false;
            return "";
        }
        
    }
    
    public String preRegisterPage(){
        newUser = new User();
        return "registeruser";
    }
    
     public String preUserConfigurationPage(){
        newUser = new User();
        return "userconfiguration";
    }
    
    
    public String registerUser(){
        newUser = new User();
        return "registeruser";
    }
    
    public void addInfo(String message) {  
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,message," "));  
    }  
  
    public void addWarn(String message) {  
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,message, " "));  
    }  
  
    public void addError(String message) {  
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,message, " "));  
    }  
  
    public void addFatal(ActionEvent actionEvent) {  
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL,"Sample fatal message", "Fatal Error in System"));  
    }  
    
     public void setUserInSession(String username) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(true);
        session.setAttribute("username", username);
    }
    
     public void setUserRoleInSession(String role) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(true);
        session.setAttribute("role", role);
    } 
}
