/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.beans;

import com.cis.models.Placements;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author home
 */
public class PlacementsBean {
    
   
    
    
    
}
