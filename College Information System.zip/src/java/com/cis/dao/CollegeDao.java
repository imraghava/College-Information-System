/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.dao;

import com.cis.models.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

/**
 *
 * @author home
 */
public class CollegeDao extends GlobalConn{
    
    public void addCollegeInfo(College clg){
        String queryToAddClgInfo = "insert into clg_college values (?,?,?,?,?,?,?,?)";
        Connection conn = null;
        try{
            conn=getDBConnection();
            PreparedStatement ps = conn.prepareCall(queryToAddClgInfo);
            System.out.println(" college name -- "+clg.getCollegeName());
            ps.setString(1, clg.getCollegeName());
            ps.setString(2, clg.getCollegeCode());
            ps.setString(3, clg.getCollegeAllocation());
            ps.setString(4, clg.getBusFacility());
            ps.setString(5, clg.getHostelFacility());
            ps.setString(6, clg.getMtechFacility());
            ps.setString(7, clg.getHasMBA());
            ps.setString(8, clg.getHasGateCoaching());
            ps.executeUpdate();
            clg.setErrorMessage("success");
            closeAndCommintConn(conn, null);
        }catch(SQLException sqlex){
            if(sqlex.getMessage().contains("ORA-00001")){
                clg.setErrorMessage("Provided College Code Information is already present in the system.");
            }else{
                clg.setErrorMessage("Some technical error occurred. Please contact support.");
            }
            closeAndRollbackConn(conn, null);
            sqlex.printStackTrace();
        }
    }
    
    public List<College> searchCollegeInfo(College searchClg){
        String querySearchClg = "select * from clg_college where 1=1";
        if(searchClg.getCollegeCode() != null && !"".equals(searchClg.getCollegeCode())){
            querySearchClg = querySearchClg +" and collegecode='"+searchClg.getCollegeCode()+"'";
        }
        
        if(searchClg.getCollegeName() != null && !"".equals(searchClg.getCollegeName())){
            querySearchClg = querySearchClg +" and collegename='"+searchClg.getCollegeName()+"'";
        }
        
        if(searchClg.getCollegeAllocation() != null && !"".equals(searchClg.getCollegeAllocation())){
            querySearchClg = querySearchClg +" and COLLEGELOCATION='"+searchClg.getCollegeAllocation()+"'";
        }
        
        if(searchClg.getHostelFacility() != null && !"".equals(searchClg.getHostelFacility())){
            querySearchClg = querySearchClg +" and HOSTELFACILITY='"+searchClg.getHostelFacility()+"'";
        }
        
         if(searchClg.getHasGateCoaching() != null && !"".equals(searchClg.getHasGateCoaching())){
            querySearchClg = querySearchClg +" and MTECH='"+searchClg.getHasGateCoaching()+"'";
        }
        
        Connection conn = null;
        ResultSet rs = null;
        List<College> collegesList = new ArrayList();
        try{
            conn = getDBConnection();
            System.out.println(" querySearchClg ---> "+querySearchClg);
            PreparedStatement ps = conn.prepareStatement(querySearchClg);
            rs = ps.executeQuery();
            College clg = null;
            while(rs.next()){
                clg = new College();
                clg.setCollegeName(rs.getString("COLLEGENAME"));
                clg.setCollegeCode(rs.getString("COLLEGECODE"));
                clg.setCollegeAllocation(rs.getString("COLLEGELOCATION"));
                clg.setBusFacility(rs.getString("BUSFACILITY"));
                clg.setHostelFacility(rs.getString("HOSTELFACILITY"));
                clg.setMtechFacility(rs.getString("MTECH"));
                clg.setHasMBA(rs.getString("MBA"));
                clg.setBusFacility(rs.getString("MS"));
                collegesList.add(clg);
            }
            closeAndCommintConn(conn, rs);
        }catch(SQLException sql){
            closeAndRollbackConn(conn, rs);
            sql.printStackTrace();
        }
        return collegesList;
    }
    
    
    public List<College> searchCollegeInfoBasedOnRank(College searchClg){
        String querySearchClg = "select * from clg_college where "
                + "collegecode in (select distinct clg.collegecode from clg_college clg, clg_rank rank "
                + "where clg.collegecode = rank.collegecode and rank.minrank >= "+searchClg.getStudentRank()+")";
        Connection conn = null;
        ResultSet rs = null;
        List<College> collegesList = new ArrayList();
        try{
            conn = getDBConnection();
            System.out.println(" querySearchClg ---> "+querySearchClg);
            PreparedStatement ps = conn.prepareStatement(querySearchClg);
            rs = ps.executeQuery();
            College clg = null;
            while(rs.next()){
                clg = new College();
                clg.setCollegeName(rs.getString("COLLEGENAME"));
                clg.setCollegeCode(rs.getString("COLLEGECODE"));
                clg.setCollegeAllocation(rs.getString("COLLEGELOCATION"));
                clg.setBusFacility(rs.getString("BUSFACILITY"));
                clg.setHostelFacility(rs.getString("HOSTELFACILITY"));
                clg.setMtechFacility(rs.getString("MTECH"));
                clg.setHasMBA(rs.getString("MBA"));
                clg.setBusFacility(rs.getString("MS"));
                collegesList.add(clg);
            }
            closeAndCommintConn(conn, rs);
        }catch(SQLException sql){
            closeAndRollbackConn(conn, rs);
            sql.printStackTrace();
        }
        return collegesList;
    }
    
    
    public void viewCollegeDetails(College clg){
        String queryToGetDeparts= "select * from CLG_DEPARTMENT where collegecode = '"+clg.getCollegeCode()+"'";
        List<Department> deparmentList = new ArrayList<Department>();
        List<Placements> placementList = new ArrayList<Placements>();
        List<Event> eventsList = new ArrayList<Event>();
        List<RankRange> ranksList = new ArrayList<RankRange>();
        String queryToGetEvents= "select * from CLG_EVENTS where collegecode ='"+clg.getCollegeCode()+"'";
        String queryToGetPlacements= "select * from CLG_PLACEMENTS where collegecode ='"+clg.getCollegeCode()+"'";
        String queryToGetRanks= "select * from CLG_RANK where collegecode ='"+clg.getCollegeCode()+"'";
        Connection conn = null;
        ResultSet rs = null;
        try{
            conn = getDBConnection();
            PreparedStatement ps = conn.prepareStatement(queryToGetDeparts);
            rs = ps.executeQuery();
            Placements placement = null;
            Department dep = null;
            
            while(rs.next()){
                dep = new Department();
                dep.setCollegeCode(rs.getString("COLLEGECODE"));
                dep.setDepartName(rs.getString("DEPARTMENTNAME"));
                dep.setNoOfSeats(rs.getInt("NUMBEROFSEATS"));
                deparmentList.add(dep);
            }
            
            rs.close();
             
            if(!"ADMIN".equals(getUserRoleInSession())){
                queryToGetPlacements = queryToGetPlacements+" and flag=1";
            }
            ps = conn.prepareStatement(queryToGetPlacements) ;
            rs = ps.executeQuery();
            while(rs.next()){
                placement = new Placements();
                placement.setCollegeCode(rs.getString("COLLEGECODE"));
                placement.setCompany(rs.getString("COMPANY"));
                placement.setDepartmentName(rs.getString("DEPTNAME"));
                placement.setTotalStudents(rs.getInt("NOOFSTUDENTS"));
                placement.setStatus(rs.getString("FLAG"));
                placementList.add(placement);
            }
            rs.close();
            
            
            
            ps = conn.prepareStatement(queryToGetEvents);
            System.out.println(" query to get events "+queryToGetEvents);
            rs = ps.executeQuery();
            Event event = null;
            while(rs.next()){
               event = new Event();
               event.setCollegeCode(rs.getString("COLLEGECODE"));
               event.setDeptName(rs.getString("DEPTNAME"));
               event.setEventsHeld(rs.getString("EVENTSHELD"));
               event.setDescription(rs.getString("DESCRIPTION"));
               eventsList.add(event);
            }
            rs.close();
            
            ps = conn.prepareStatement(queryToGetRanks);
            System.out.println(" query to get ranks "+queryToGetRanks);
            rs = ps.executeQuery();
            RankRange rank = null;
            while(rs.next()){
               rank = new RankRange();
               rank.setCollegeCode(rs.getString("COLLEGECODE"));
               rank.setDeptName(rs.getString("DEPTNAME"));
               rank.setCategory(rs.getString("CATEGORY"));
               rank.setMinRank(rs.getInt("MINRANK"));
               rank.setMaxRank(rs.getInt("MAXRANK"));
               ranksList.add(rank);
            }
            
            clg.setDeparmentList(deparmentList);            
            clg.setEventsList(eventsList);
            clg.setPlacementList(placementList);
            clg.setRanksList(ranksList);
            closeAndCommintConn(conn, rs);
        }catch(SQLException ex){
            closeAndRollbackConn(conn, rs);
            ex.printStackTrace();
        }
    }
    
    public void addReviewComments(Comments reviewCmnts){
        String queryAddComments = "insert into clg_feedback values (review_seq.nextval,?,?,?,?,?,?)";
        Connection conn = null;
        try{
            conn = getDBConnection();
            PreparedStatement ps = conn.prepareStatement(queryAddComments);
            ps.setString(1, reviewCmnts.getUserName());
            ps.setString(2, reviewCmnts.getCollegeName());
            ps.setString(3, reviewCmnts.getCollegeCode());
            ps.setString(4, reviewCmnts.getReviewComments());
            ps.setTimestamp(5, new java.sql.Timestamp((new java.util.Date()).getTime()));
            ps.setInt(6,reviewCmnts.getRatings());
            ps.executeUpdate();
            closeAndCommintConn(conn, null);
        }catch(SQLException sql){
            closeAndRollbackConn(conn, null);
            sql.printStackTrace();
        }
        
    }
    
    public List<Comments> getReviewComments(Comments reviewCmnts){
        String queryGetComments = "select * from  clg_feedback where collegecode = '"+reviewCmnts.getCollegeCode()+"' order by commentsid";
        Connection conn = null;
        List<Comments> commentsList = new ArrayList<Comments>();
        ResultSet rs = null;
        try{
            conn = getDBConnection();
            PreparedStatement ps = conn.prepareStatement(queryGetComments);
            rs= ps.executeQuery();
            Comments comment = null;
            while(rs.next()){
                comment = new Comments();
                comment.setSeqId(rs.getInt("COMMENTSID"));
                comment.setUserName(rs.getString("USERNAME"));
                comment.setCollegeName(rs.getString("COLLEGENAME"));
                comment.setCollegeCode(rs.getString("COLLEGECODE"));
                comment.setReviewComments(rs.getString("COMMENTS"));
                commentsList.add(comment);
            }
            closeAndCommintConn(conn, null);
        }catch(SQLException sql){
            closeAndRollbackConn(conn, null);
            sql.printStackTrace();
        }
        return commentsList;
        
    }
    
     public String getUserRoleInSession(){
        FacesContext facesContext = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(true);
        String role = (String)session.getAttribute("role");
        return role;
    } 
    
}
