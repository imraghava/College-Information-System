/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.dao;

import com.cis.models.College;
import com.cis.models.Department;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author home
 */
public class DepartmentDao extends GlobalConn{
    
    public String addDepartmentInfo(String collegeCode,List<Department> departmentList){
        String queryToAddDepInfo = "insert into clg_department values (?,?,?)";
        Connection conn = null;
        String mesg = null;
        try{
            conn=getDBConnection();
            PreparedStatement ps = null;
            System.out.println(" qu name -- "+queryToAddDepInfo);
            for(Department dep : departmentList){
                ps =  conn.prepareCall(queryToAddDepInfo);
                ps.setString(1, collegeCode);
                ps.setString(2, dep.getDepartName());
                ps.setInt(3, dep.getNoOfSeats());
               ps.executeUpdate();
            }
            mesg = "success";
            closeAndCommintConn(conn, null);
        }catch(SQLException sqlex){
            mesg = "Error Occurred.";
            closeAndRollbackConn(conn, null);
            sqlex.printStackTrace();
        }
        return mesg;
    }
    
}
