/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.dao;

import com.cis.models.Department;
import com.cis.models.Event;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author home
 */
public class EventsDao extends GlobalConn {
     public String addEventsInfo(List<Event> eventsList){
        String queryToAddEventInfo = "insert into clg_events values (?,?,?,sysdate,?)";
        Connection conn = null;
        String mesg = null;
        try{
            conn=getDBConnection();
            PreparedStatement ps = null;
            System.out.println(" qu name -- "+queryToAddEventInfo);
            for(Event event : eventsList){
                ps =  conn.prepareCall(queryToAddEventInfo);
                ps.setString(1, event.getCollegeCode());
                ps.setString(2, event.getDeptName());
                ps.setString(3, event.getEventsHeld());
                ps.setString(4, event.getDescription());
               ps.executeUpdate();
            }
            mesg = "success";
            closeAndCommintConn(conn, null);
        }catch(SQLException sqlex){
            mesg = " Error occurred ";
            closeAndRollbackConn(conn, null);
            sqlex.printStackTrace();
        }
        return mesg;
    }
}
