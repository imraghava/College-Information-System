/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author home
 */
public class GlobalConn {
    

    public Connection getDBConnection(){
        Properties props = new Properties();
        props.put("user", "bhojreddy");
        props.put("password", "bhojreddy");
        Connection conn = null;
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XE", props);
            conn.setAutoCommit(false);
        }catch(SQLException ex){
            ex.printStackTrace();
        }catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }
        return conn;
    }
    
    public void closeAndCommintConn(Connection conn,ResultSet rs){
            try {
                if(rs != null){
                    rs.close();
                }
                
                if(null != conn){
                    conn.commit();
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(GlobalConn.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
   
     public void closeAndRollbackConn(Connection conn,ResultSet rs){
            try {
                if(rs != null){
                    rs.close();
                }
                if(null != conn){
                    conn.rollback();
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(GlobalConn.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
}
