/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.dao;

import com.cis.models.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


/**
 *
 * @author home
 */
public class LoginDao extends GlobalConn{
    
    public String validateUser(User userObj){
        String output = "success";
        String query = "select typeofusers,userdetails from clg_users where username='"+userObj.getUserName()+"'"
                + " and password='"+userObj.getPassword()+"'";
        
        System.out.println("login query: "+query);
        Connection conn = getDBConnection();
        try{
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet resultset = ps.executeQuery();
             if(resultset.next()){
                 userObj.setTypeOfUser(resultset.getString(1));
                 userObj.setUserDetails(resultset.getString(2));
             }else{
                 System.out.println(" The user does not exist --- LoginDAO class");
                 output = "failed";
             }
             closeAndCommintConn(conn, resultset);
        }catch(Exception ex){
            closeAndRollbackConn(conn, null);
            output = "failed";
            ex.printStackTrace();
        }
       return output;
    }
    
    
    public String addNewUser(User userObj){
        String output = "success";
        String insertQuery = "insert into clg_users values (?,?,?,?,?,?)";
        
        System.out.println("insert query: "+insertQuery);
        Connection conn = getDBConnection();
        try{
             PreparedStatement ps = conn.prepareStatement(insertQuery);
             ps.setString(1, userObj.getUserName());
             ps.setString(2, userObj.getPassword());
             ps.setString(3, userObj.getUserDetails());
             ps.setString(4, userObj.getEmailAddress());
             ps.setInt(5, 1);
             ps.setString(6, userObj.getTypeOfUser());
             ps.executeUpdate();
             closeAndCommintConn(conn, null);
             output = "success";
        }catch(Exception ex){
            closeAndRollbackConn(conn, null);
            output = "Technical error occurred. Please contact support team.";
            ex.printStackTrace();
        }
       return output;
    }
    
}
