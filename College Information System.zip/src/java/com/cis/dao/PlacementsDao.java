/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.dao;

import com.cis.models.College;
import com.cis.models.Placements;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author home
 */
public class PlacementsDao extends GlobalConn{
    
    public String addPlacementsInfo(List<Placements> placementsList){
        String queryToAddPlacementsInfo = "insert into clg_placements values (?,?,?,?,sysdate,0)";
        Connection conn = null;
        String mesg = null;
        try{
            conn=getDBConnection();
            PreparedStatement ps = null;
            for(Placements obj : placementsList){
                ps =conn.prepareCall(queryToAddPlacementsInfo);
                ps.setString(1, obj.getCompany());
                ps.setString(2, obj.getCollegeCode());
                ps.setString(3, obj.getDepartmentName());
                ps.setInt(4, obj.getTotalStudents());
                ps.executeUpdate();
            }
            mesg = "success";
            closeAndCommintConn(conn, null);
        }catch(SQLException sqlex){
            mesg = "Error occurred";
            closeAndRollbackConn(conn, null);
            sqlex.printStackTrace();
        }
        return mesg;
    }
    
    public String activatePlacements(String collegeCode){
        String updatePlacements = "update clg_placements set flag=1 where collegecode = '"+collegeCode+"'";
        Connection conn = null;
        String mesg = null;
        try{
            conn=getDBConnection();
            PreparedStatement ps = null;
            ps =conn.prepareCall(updatePlacements);
            ps.executeUpdate();
            mesg = "success";
            closeAndCommintConn(conn, null);
        }catch(SQLException sqlex){
            mesg = "Error occurred";
            closeAndRollbackConn(conn, null);
            sqlex.printStackTrace();
        }
        return mesg;
    }
}
