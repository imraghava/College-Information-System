/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.dao;

import com.cis.models.College;
import com.cis.models.RankRange;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author home
 */
public class RankDao extends GlobalConn{
    
    public String addRankInfo(String collegeCode,List<RankRange> ranksList){
        String queryToAddRanks = "insert into clg_rank values (?,?,?,?,?)";
        Connection conn = null;
        String mesg = null;
        try{
            conn=getDBConnection();
            PreparedStatement ps = null;
            for(RankRange obj : ranksList){
                ps =conn.prepareCall(queryToAddRanks);
                ps.setString(1, obj.getCollegeCode());
                ps.setString(2, obj.getDeptName());
                ps.setString(3, obj.getCategory());
                ps.setInt(4, obj.getMinRank());
                ps.setInt(5, obj.getMaxRank());
                ps.executeUpdate();
            }
            mesg = "success";
            closeAndCommintConn(conn, null);
        }catch(SQLException sqlex){
            mesg = "Error occurred.";
            closeAndRollbackConn(conn, null);
            sqlex.printStackTrace();
        }
        return mesg;
    }
    
    public List<College> searchCollegeInfo(College searchClg){
        String querySearchClg = "select * from clg_college where 1=1";
        if(searchClg.getCollegeCode() != null && !"".equals(searchClg.getCollegeCode())){
            querySearchClg = searchClg +" and collegecode='"+searchClg.getCollegeCode()+"'";
        }
        
        if(searchClg.getCollegeName() != null && !"".equals(searchClg.getCollegeName())){
            querySearchClg = searchClg +" and collegename='"+searchClg.getCollegeName()+"'";
        }
        Connection conn = null;
        ResultSet rs = null;
        List<College> collegesList = new ArrayList();
        try{
            conn = getDBConnection();
            System.out.println(" querySearchClg ---> "+querySearchClg);
            PreparedStatement ps = conn.prepareStatement(querySearchClg);
            rs = ps.executeQuery();
            College clg = null;
            while(rs.next()){
                clg = new College();
                clg.setCollegeName(rs.getString("COLLEGENAME"));
                clg.setCollegeCode(rs.getString("COLLEGECODE"));
                clg.setCollegeAllocation(rs.getString("COLLEGELOCATION"));
                clg.setBusFacility(rs.getString("BUSFACILITY"));
                clg.setHostelFacility(rs.getString("HOSTELFACILITY"));
                clg.setMtechFacility(rs.getString("MTECH"));
                clg.setHasMBA(rs.getString("MBA"));
                clg.setBusFacility(rs.getString("MS"));
                collegesList.add(clg);
            }
            closeAndCommintConn(conn, rs);
        }catch(SQLException sql){
            closeAndRollbackConn(conn, rs);
            sql.printStackTrace();
        }
        return collegesList;
    }
    
}
