/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.models;

import java.util.List;

/**
 *
 * @author home
 */
public class College {
    
    private String studentRank;
    private String collegeName;
    private String collegeCode;
    private String collegeAllocation;
    private String busFacility;
    private String hostelFacility;
    private String errorMessage;
    
    
    
    private String hasMBA;
    private String hasGateCoaching;
    private String mtechFacility;
    
    private List<Department> deparmentList;
    private List<Placements> placementList;
    private List<Event> eventsList;
    private List<RankRange> ranksList;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    
    public List<RankRange> getRanksList() {
        return ranksList;
    }

    public void setRanksList(List<RankRange> ranksList) {
        this.ranksList = ranksList;
    }

    
    public List<Event> getEventsList() {
        return eventsList;
    }

    public void setEventsList(List<Event> eventsList) {
        this.eventsList = eventsList;
    }
    
    public List<Placements> getPlacementList() {
        return placementList;
    }

    public void setPlacementList(List<Placements> placementList) {
        this.placementList = placementList;
    }
    
    

    public List<Department> getDeparmentList() {
        return deparmentList;
    }

    public void setDeparmentList(List<Department> deparmentList) {
        this.deparmentList = deparmentList;
    }
    
    
    

    public String getStudentRank() {
        return studentRank;
    }

    public void setStudentRank(String studentRank) {
        this.studentRank = studentRank;
    }

    
    
    public String getMtechFacility() {
        return mtechFacility;
    }

    public void setMtechFacility(String mtechFacility) {
        this.mtechFacility = mtechFacility;
    }
    
    

    public String getBusFacility() {
        return busFacility;
    }

    public void setBusFacility(String busFacility) {
        this.busFacility = busFacility;
    }

    public String getCollegeAllocation() {
        return collegeAllocation;
    }

    public void setCollegeAllocation(String collegeAllocation) {
        this.collegeAllocation = collegeAllocation;
    }

    public String getCollegeCode() {
        return collegeCode;
    }

    public void setCollegeCode(String collegeCode) {
        this.collegeCode = collegeCode;
    }

    public String getCollegeName() {
        return collegeName;
    }

    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }

    public String getHasGateCoaching() {
        return hasGateCoaching;
    }

    public void setHasGateCoaching(String hasGateCoaching) {
        this.hasGateCoaching = hasGateCoaching;
    }

    public String getHasMBA() {
        return hasMBA;
    }

    public void setHasMBA(String hasMBA) {
        this.hasMBA = hasMBA;
    }

    public String getHostelFacility() {
        return hostelFacility;
    }

    public void setHostelFacility(String hostelFacility) {
        this.hostelFacility = hostelFacility;
    }

    
    
    
}
