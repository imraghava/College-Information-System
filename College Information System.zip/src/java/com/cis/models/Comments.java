/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.models;

/**
 *
 * @author home
 */
public class Comments {
    private String userName;
    private String collegeCode;
    private String collegeName;
    private String reviewComments;
    private String reviewSeq;
    private String timeStamp;
    private int ratings;
    private int seqId;

    public int getSeqId() {
        return seqId;
    }

    public void setSeqId(int seqId) {
        this.seqId = seqId;
    }
    
    public int getRatings() {
        return ratings;
    }

    public void setRatings(int ratings) {
        this.ratings = ratings;
    }
    
    

    public String getCollegeCode() {
        return collegeCode;
    }

    public void setCollegeCode(String collegeCode) {
        this.collegeCode = collegeCode;
    }

    public String getCollegeName() {
        return collegeName;
    }

    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }

    public String getReviewComments() {
        return reviewComments;
    }

    public void setReviewComments(String reviewComments) {
        this.reviewComments = reviewComments;
    }

    public String getReviewSeq() {
        return reviewSeq;
    }

    public void setReviewSeq(String reviewSeq) {
        this.reviewSeq = reviewSeq;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    
    
}
