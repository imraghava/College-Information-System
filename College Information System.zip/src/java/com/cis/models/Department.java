/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.models;

/**
 *
 * @author home
 */
public class Department {
    private String collegeCode;
    private String departName;
    private int noOfSeats;

    public String getCollegeCode() {
        return collegeCode;
    }

    public void setCollegeCode(String collegeCode) {
        this.collegeCode = collegeCode;
    }

    public String getDepartName() {
        return departName;
    }

    public void setDepartName(String departName) {
        this.departName = departName;
    }

    public int getNoOfSeats() {
        return noOfSeats;
    }

    public void setNoOfSeats(int noOfSeats) {
        this.noOfSeats = noOfSeats;
    }

   
    
    
}
