/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.models;

import java.util.Date;

/**
 *
 * @author home
 */
public class Event {
    private String collegeCode;
    private String deptName;
    private String eventsHeld;
    private Date yearValue;
    private String description;

    public String getCollegeCode() {
        return collegeCode;
    }

    public void setCollegeCode(String collegeCode) {
        this.collegeCode = collegeCode;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEventsHeld() {
        return eventsHeld;
    }

    public void setEventsHeld(String eventsHeld) {
        this.eventsHeld = eventsHeld;
    }

    public Date getYearValue() {
        return yearValue;
    }

    public void setYearValue(Date yearValue) {
        this.yearValue = yearValue;
    }
    
    
    
    
}
