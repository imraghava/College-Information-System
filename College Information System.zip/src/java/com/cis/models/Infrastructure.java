/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.models;

/**
 *
 * @author home
 */
public class Infrastructure {
    private String collegeCode;
    private String deptName;
    private String description;

    public String getCollegeCode() {
        return collegeCode;
    }

    public void setCollegeCode(String collegeCode) {
        this.collegeCode = collegeCode;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    
}
