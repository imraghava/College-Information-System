/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.models;

/**
 *
 * @author home
 */
public class Library {
    private String collegeCode;
    private String departName;
    private String noOfVolumes;
    private String description;

    public String getCollegeCode() {
        return collegeCode;
    }

    public void setCollegeCode(String collegeCode) {
        this.collegeCode = collegeCode;
    }

    public String getDepartName() {
        return departName;
    }

    public void setDepartName(String departName) {
        this.departName = departName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNoOfVolumes() {
        return noOfVolumes;
    }

    public void setNoOfVolumes(String noOfVolumes) {
        this.noOfVolumes = noOfVolumes;
    }
    
    
}
