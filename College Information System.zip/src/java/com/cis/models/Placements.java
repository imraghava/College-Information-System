/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cis.models;

import java.util.Date;

/**
 *
 * @author home
 */
public class Placements {
    
    private String company;
    private String collegeCode;
    private String departmentName;
    private int totalStudents;
    private Date yearOfPlacement;
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        if("1".equals(status)){
            this.status = "Active";
        }else{
            this.status = "Inactive";
        }
        
    }
    
    

    public String getCollegeCode() {
        return collegeCode;
    }

    public void setCollegeCode(String collegeCode) {
        this.collegeCode = collegeCode;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public int getTotalStudents() {
        return totalStudents;
    }

    public void setTotalStudents(int totalStudents) {
        this.totalStudents = totalStudents;
    }

    public Date getYearOfPlacement() {
        return yearOfPlacement;
    }

    public void setYearOfPlacement(Date yearOfPlacement) {
        this.yearOfPlacement = yearOfPlacement;
    }
    
    
    
}
